var abcde=document.querySelector(".abcde");
var abcdef=document.querySelector(".abcdef")
setInterval(function(){
    abcdef.style="opacity:0;transition:0.75s;"
},2500)
setInterval(function(){
    abcdef.style="opacity:1;transition:0.75s;"
},5000);
abcdef.onclick=function(){
    location.href="#"
}
abcde.onclick=function(){
    location.href="#"
}