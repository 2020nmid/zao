var oheada = document.querySelectorAll(".head-nav li a");
    for(let i = 0;i<oheada.length;i++){
        oheada[i].setAttribute("target","_blank");
    }
var ainput = document.querySelector(".search input");
    ainput.setAttribute("placeholder","你这外星人是想笑死我吗?");
var abutton =document.querySelector(".search button"); 
var aimg =document.querySelector(".search button img");
 aimg.setAttribute("src","img/search1.png");
 abutton.onmouseenter=function(){
    aimg.setAttribute("src","img/search2.png");
 }
 abutton.onmouseleave=function(){
    aimg.setAttribute("src","img/search1.png");
 }
 var agundong = document.querySelector(".gundong a img");
 var ogundong = document.querySelector(".gundong a i")
    setInterval(function(){
        agundong.setAttribute("style","display:block");
        ogundong.setAttribute("style","transform:translateY(10px)");
    },6000);
var ochange = document.querySelectorAll(".change div");
var oi =document.querySelectorAll(".change div i");
    for(let i=0;i<ochange.length;i++){
        ochange[i].onclick =function(){
            if(i===0){
                oi[i+1].style="display:block";
                oi[i+3].style="display:none";
                ochange[i].style="color:rgb(0,160,216)";
                ochange[i+1].style="color:blank";
            }
            if(i==1){
                oi[i].style="display:none";
                oi[i+2].style="display:block";
                ochange[i-1].style="color:blank";
                ochange[i].style="color:rgb(0,160,216)";
            }
        }
    }