var athree = document.querySelector(".three img");
    athree.onmouseenter=function(){
        athree.removeAttribute("src");
        athree.setAttribute("src","img/change.png");
        athree.setAttribute("style","height:200px;width:400px")
    }
    athree.onmouseleave=function(){
        athree.removeAttribute("src");
        athree.removeAttribute("style");
        athree.setAttribute("src","img/code.png");
    }
    var achick = document.querySelector(".chick");
    var i = 0;
    achick.onclick=function(){
        if(i%2===0)
        {
            achick.style="background:url('img/chick.png');background-size:13px 13px";
            i++;
        }
        else
        {
            achick.style="";
            i++;
        }
    }
var tel=document.querySelector(".newinput input");
var text=document.querySelector(".first");
var img=document.querySelector(".second");
var ap=document.querySelector(".codesend");
var anew=document.querySelector(".newinput1 button");
var sp=document.querySelector(".third");
var si=document.querySelector(".top");
var sim=document.querySelector(".bigimg");
var bod=document.querySelector("body");
var sc=document.querySelector("#beiyong");
var se=document.querySelector(".beiyong1");
var posX=0;var posY=0;
var count=1;
var arr=new Array(0,0,0,0);
var num = 3;
var flag=false;var ok=false;
var all=document.querySelectorAll("area");
var mag=Math.floor(Math.random()*5)+1;
var mapmag=document.querySelectorAll("area");
for(var i=0;i<all.length;i++){
    all[i].href="javascript:;";
    all[i].style="cursor: default;";
} 
    anew.onclick=function(){
        sc.style="display:none;";
        se.style="display:none;";
        location.href="#one";
        location.hash="#one";
        if(tel.value==""){
            tel.style="border:1px solid rgb(246,100,149)";
            text.innerHTML="手机号不能为空喔";
            img.style="opacity:1;";
            return 0;
        }
        if(tel.value.length!=11){
            tel.style="border:1px solid rgb(246,100,149)";
            text.innerHTML="手机号格式错误";
            img.style="opacity:1;";
            return 0;
        }
        var a=tel.value;
        if(a[0]!=1){
            flag=true;
        }
        if(a[1]!=3){
            if(a[1]!=4){
                if(a[1]!=5){
                    if(a[1]!=7){
                        if(a[1]!=8){
                            flag=true;
                        }else flag=false;
                    } else flag=false;
                } else flag=false;
            }
            else flag=false;
        }
        else flag=false;
        for(var i=2;i<11;i++){
            if(a[i]>"9"||a[i]<"0"){
                flag=true;
                break;
            }
        }
        if(flag){
            tel.style="border:1px solid rgb(246,100,149)";
            text.innerHTML="手机号格式错误";
            img.style="opacity:1;";
            return 0;
        }
        else{
            tel.style="border:0;";
            text.innerHTML="";
            img.style="opacity:0;";
        }
        var ca=document.querySelectorAll(".bott a");
        ca[0].onclick=function()
        {
            sp.style="display:none;transition:1s";
            var closedd=document.querySelectorAll("#chuandiv");
                for(let i=0;i<closedd.length;i++){
                    closedd[i].remove();
                }
                reset(arr);
                count=1;
            return 0;
        }
        ca[1].onclick=function (){
            var a=document.querySelectorAll("#chuandiv");
            for(var i=0;i<a.length;i++){
                a[i].remove();
            }
            count=1;
            mag=Math.floor(Math.random()*5)+1;
            num = 3;
            if(mag==1||mag==2) num=4;
            sim.setAttribute("usemap","#map"+mag);
            reset(arr);
            si.style="background:url(img/"+mag+".jpg) -5px -349px";
            sim.style="background:url(img/"+mag+".jpg) 0px 0px no-repeat;background-size:100% 112%;";
        }
        sp.style="display:block;transition:1s;";
        si.style="background:url(img/"+mag+".jpg) -5px -349px";
        sim.style="background:url(img/"+mag+".jpg) 0px 0px no-repeat;background-size:100% 112%;";
        if(mag==1||mag==2)
            {num=4;}
        sim.setAttribute("usemap","#map"+mag);
        for(let i=0;i<mapmag.length;i++)
        {
            sim.onclick=function()
            {
                if(count>num){
                    return 0;
                }
                var child=document.createElement("div");
                child.setAttribute("id","chuandiv");
                child.textContent=count;
                var chicked=sim.addEventListener('mousemove',getPointerPosition(posX,posY))
                function getPointerPosition(posX,posY) {
                    var event = event || window.event;
                    if (event.pageX || event.pageY) {
                    posX = event.pageX;
                    posY = event.pageY;
                    } else if (event.clientX || event.clientY) {
                    posX = event.clientX + document.documentElement.scrollLeft + document.body.scrollLeft;
                    posY = event.clientY + document.documentElement.scrollTop + document.body.scrollTop;
                    }
                    child.style="top:"+posY+"px;left:"+posX+"px;";
                    return new Array(posX,posY);
                }
                count++;
                bod.appendChild(child);
                var a=document.querySelectorAll("#chuandiv");
                for(let i=0;i<a.length;i++){
                    a[i].onclick=function(){
                        for(let j=i;j<a.length;j++){
                            a[j].remove();
                        }
                        count=i+1;
                    }
                }
            }
            mapmag[i].onclick=function()
            {
                if(count>num){
                    return 0;
                }
                var child=document.createElement("div");
                child.setAttribute("id","chuandiv");
                child.textContent=count;
                var chicked=sim.addEventListener('mousemove',getPointerPosition(posX,posY))
                function getPointerPosition(posX,posY) {
                    var event = event || window.event;
                    if (event.pageX || event.pageY) {
                    posX = event.pageX;
                    posY = event.pageY;
                    } else if (event.clientX || event.clientY) {
                    posX = event.clientX + document.documentElement.scrollLeft + document.body.scrollLeft;
                    posY = event.clientY + document.documentElement.scrollTop + document.body.scrollTop;
                    }
                    child.style="top:"+posY+"px;left:"+posX+"px;";
                }
                count++;
                bod.appendChild(child);
                var a=document.querySelectorAll("#chuandiv");
                for(let i=0;i<a.length;i++)
                {
                    a[i].onclick=function(){
                        for(let j=i;j<a.length;j++){
                            a[j].remove();
                            arr[j]=0;
                        }
                        count=i+1;
                    }
                }
                var m=new Array(0,4,8,11,14);
                    if((i-m[mag-1])==(count-2)){
                        arr[count-2]=1;
                    }
            }
        
        }
        var dui=document.querySelector(".bott button");
        dui.onclick=function()
        {
            for(var i =0;i<num;i++)
            {
            if(arr[i])
            {ok=true;}
            else
            {ok=false;break;}
            }
            reset(arr);
            var su=document.querySelector(".succ");
            if(ok){
                var xiu=window.getComputedStyle(sp,":before");
                su.textContent="通过验证";
                su.style="display:block;";
                ap.textContent="验证码已发送,5分钟内有效"; 
                setTimeout(function(){
                    su.style="display:none;";
                },1000);
                var a=document.querySelectorAll("#chuandiv");
                for(var i=0;i<a.length;i++){
                    a[i].remove();
                }
                count=1;
                setTimeout(function()
                {
                    se.style="display:block";
                    sp.style="display:none;";
                    setTimeout(function()
                    {
                        se.style="display:none;";
                        sc.style="display:block;";
                    },700);
                },1000);
                setTimeout(function()
                {
                    var yuan=anew.style;
                    var a=60;
                    anew.style="background-color:rgb(245,245,245);color:rgb(184,184,184);"
                    var id=setInterval(function(){
                        anew.textContent=a+"s后重试";
                        anew.setAttribute("disabled","disabled");
                        a--;
                        if(a==0){
                            clearInterval(id);
                            anew.removeAttribute("disabled");
                            anew.style=yuan;
                            anew.textContent="重新获取验证码";
                        }
                    }, 1000);
                },2000)
                
            }
            else{
                var su=document.querySelector(".succ");
                su.textContent="验证失败"
                su.style="display:block;background-color:rgb(222,113,91);";
                setTimeout(function (){
                    mag=Math.floor(Math.random()*5)+1;
                    num=3;
                    if(mag==1||mag==2) num=4;
                    sim.setAttribute("usemap","#map"+mag);
                    reset(arr);
                    var a=document.querySelectorAll("#chuandiv");
                    for(var i=0;i<a.length;i++){
                        a[i].remove();
                    }
                    si.style="background:url(img/"+mag+".jpg) -5px -349px";
                    sim.style="background:url(img/"+mag+".jpg) 0px 0px no-repeat;background-size:100% 112%;";
                    setTimeout(function(){
                        su.style="display:none;";
                    },500);
                },1000);
                count=1;
            } 
        }
} 
var ochangea = document.querySelectorAll(".changea a");
var one=document.querySelector("#one");
var two=document.querySelector("#two");
var three=document.querySelector(".newinput");
var four=document.querySelector(".newinput1");
    ochangea[0].onclick = function(){
        ochangea[0].style="color:rgb(0,160,216)";
        ochangea[1].style="color:black";
        one.style="display:block";
        two.style="display:block";
        three.style="display:none";
        four.style="display:none";
        ap.textContent=" ";
        tel.style="border:0;";
        tel.value="";
        text.innerHTML="";
        img.style="opacity:0;";
        anew.textContent="获取验证码"; 
    }
    ochangea[1].onclick = function(){
        ochangea[1].style="color:rgb(0,160,216)";
        ochangea[0].style="color:black";
        one.style="display:none";
        two.style="display:none";
        three.style="display:block";
        four.style="display:block";
    }
function reset(arr){
    for(var i=0;i<4;i++){
        arr[i]=0;
    }
}