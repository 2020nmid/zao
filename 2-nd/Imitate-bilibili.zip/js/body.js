var athree = document.querySelector(".three img");
    athree.onmouseenter=function(){
        athree.removeAttribute("src");
        athree.setAttribute("src","img/change.png");
        athree.setAttribute("style","height:200px;width:400px")
    }
    athree.onmouseleave=function(){
        athree.removeAttribute("src");
        athree.removeAttribute("style");
        athree.setAttribute("src","img/code.png");
    }
    var achick = document.querySelector(".chick");
    var i = 0;
    achick.onclick=function(){
        if(i%2===0)
        {
            achick.style="background:url('img/chick.png');background-size:13px 13px";
            i++;
        }
        else
        {
            achick.style="";
            i++;
        }
    }
var ap=document.querySelector(".codesend");
var anew=document.querySelector(".newinput1 button");
    anew.onclick=function(){
        location.href="#one";
        ap.textContent="验证码已发送,5分钟内有效";
        anew.textContent="重新发送"; 
} 
var ochangea = document.querySelectorAll(".changea a");
var one=document.querySelector("#one");
var two=document.querySelector("#two");
var three=document.querySelector(".newinput");
var four=document.querySelector(".newinput1");
    ochangea[0].onclick = function(){
        ochangea[0].style="color:rgb(0,160,216)";
        ochangea[1].style="color:black";
        one.style="display:block";
        two.style="display:block";
        three.style="display:none";
        four.style="display:none";
        ap.textContent=" ";
        anew.textContent="获取验证码"; 
    }
    ochangea[1].onclick = function(){
        ochangea[1].style="color:rgb(0,160,216)";
        ochangea[0].style="color:black";
        one.style="display:none";
        two.style="display:none";
        three.style="display:block";
        four.style="display:block";
    }
